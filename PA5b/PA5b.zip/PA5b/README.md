# Q2.

reduceUnrolling8 implements data block unrolling by a factor of eight. This transformation retains that data block unrolling, but uses an eightiteration loop to implement it rather than inlining it as eight separate statements. Based on the execution output, the new version is slightly faster as compared to older version at times but even the newer version is slower than the older version (check 2nd execution). No matter which version (old or new) is faster the cause of that performance improvement will be the same.

Code Changes:
------------

The new kernel is placed under the comment - // New ReduceUnrolling8
The changes in the main function are wrapped within comments as shown below.

// kernel 7: reduceUnrolling8New START --------------------------

// kernel 7: reduceUnrolling8New END ---------------------------

To execute:

- nvcc -O3 reduceInteger.cu
- salloc -n1 --gres=gpu:1 --mem=16G -t5
- ./a.out

# Q3. 

Depending on the architecture, there may or may not be differences in performance. On older GPU architectures, contention for floating-point arithmetic logic units may lead to a loss in performance. However, on many GPUs there will be no difference in performance. As both int and float values have the same. number of bytes, the amount of I/O performed by this kernel will not change, only the hardware units used to perform arithmetic.

However, based on the execution of the program with int and floats in multiple runs, 

- On P100 for floats as compared to ints, for interleaved reduce, observed max improvement of 1e-5s and for complete unroll, observed max improvement of 5e-6s.

|   RUNS |INTERLEAVED INT|INTERLEAVED FLOAT| COMPLETE UNROLL WRAPS 8 INT|COMPLETE UNROLL WRAPS 8 FLOAT |
|----------------|-------------------------------|-----------------------------|-------------------------------|-----------------------------|
|1 (on P100)|`0.000904` |`0.000907` |`0.000197`|`0.000197`|
|2 (on K40m)|`0.004010`|`0.004013` |`0.000602`|`0.000602`|
|3 (on K40m)|`0.003977`|`0.003980`|`0.000591`|`0.000591`|

Code Changes:
-------------
Below two new kernels are added to the code along with changes in the main function. The function calls to these kernels are wrapped in comments.

> reduceInterleavedFloat 

> reduceCompleteUnrollWarps8Float

To execute:

- nvcc -O3 reduceInteger-q3.cu
- salloc -n1 --gres=gpu:1 --mem=16G -t5
- ./a.out


# Q4.

The block diagram on figure 3.30 of the homework is different than the diagram on slide 40. Since there are no arrows from the second block with 8 threads reduced to 4 threads like there are on slide 40, this is interpreted as: 

- First, block0 and block1 start with 8 threads each, 
- Second step, block0 has 8 threads and block1 doesn't call anything further. 
- Thrid step and so on, block0 will recursively call with size/2 until size=2.