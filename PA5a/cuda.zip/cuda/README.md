# Q1. 
Remove the cudaDeviceReset function in hello.cu, then compile and run it.

- When cudaDeviceReset is removed, none of the prints from the GPU are displayed. While printf is still called on the GPU, cudaDeviceReset forces those prints to be flushed from the GPU, to the host, and then output in the user-visible console. Without calling cudaDeviceReset (or other functions that force flushing of GPU output), there are no guarantees that these prints will be displayed. 


# Q2.
Replace the function cudaDeviceReset with cudaDeviceSynchronize, then compile and run it to see what happens.

- When cudaDeviceReset is replaced with cudaDeviceSynchronize, the prints from the GPU are displayed on the console.
cudaDeviceSynchronize is another function (like cudaDeviceReset) that can be used to force GPU prints to be flushed to the user-visible console.

# Q3. 

> With block.x set to 1023, sumArraysOnGPU-timer produces the following output on:

#### ------------------------------------
### EXECUTION ON A K40m
#### ------------------------------------

```c
[raidurga@e07-14 cuda]$ ./a.out 
./a.out Starting...
Using Device 0: Tesla K40m
Vector size 16777216
initialData Time elapsed 0.605568 sec
sumArraysOnHost Time elapsed 0.018942 sec
sumArraysOnGPU <<<  16401, 1023  >>>  Time elapsed 0.001610 sec
Arrays match.

```

#### ------------------------------------
### EXECUTION ON A TESLA P100
#### ------------------------------------

```c
[raidurga@d23-15 cuda]$ ./a.out 
./a.out Starting...
Using Device 0: Tesla P100-PCIE-16GB
Vector size 16777216
initialData Time elapsed 0.779229 sec
sumArraysOnHost Time elapsed 0.022437 sec
sumArraysOnGPU <<<  16401, 1023  >>>  Time elapsed 0.000606 sec
Arrays match.
```

> With block.x set to 1024, the following output is produced:

#### ------------------------------------
### EXECUTION ON A K40m
#### ------------------------------------

```c
[raidurga@e07-14 cuda]$ ./a.out 
./a.out Starting...
Using Device 0: Tesla K40m
Vector size 16777216
initialData Time elapsed 0.606307 sec
sumArraysOnHost Time elapsed 0.019125 sec
sumArraysOnGPU <<<  16384, 1024  >>>  Time elapsed 0.001548 sec
Arrays match.
```

#### ------------------------------------
### EXECUTION ON A TESLA P100
#### ------------------------------------

```c
[raidurga@d23-15 cuda]$ ./a.out 
./a.out Starting...
Using Device 0: Tesla P100-PCIE-16GB
Vector size 16777216
initialData Time elapsed 0.782630 sec
sumArraysOnHost Time elapsed 0.023442 sec
sumArraysOnGPU <<<  16384, 1024  >>>  Time elapsed 0.000512 sec
Arrays match.
``` 

Note the performance difference between the kernels with different block configurations. With block.x set to 1024 the kernel runs faster. Because threads are scheduled in groups of 32, running blocks with 1023 threads leads to two suboptimal application characteristics. 

> First, the last warp in every thread block will have a disabled thread that performs no work because 1024 is not evenly divisible into warps. 

> Second, because there are fewer threads per block the application will require more blocks to fully process the input. Running more thread blocks causes longer execution times as only a fixed number of blocks can run concurrently.

# Q4. 
In sumArraysOnGPU-timer.cu, let block.x = 256. Write a new kernel function that handles three elements. Compare the results with other grid configurations

Changing the behavior of the kernel requires changing the execution configuration of the kernel as well. Namely, one third as many threads are required to process the full input. Therefore, setting the grid size should be changed from:
``` 
dim3 grid ((nElem + block.x - 1) / block.x);
```
to 
```
dim3 grid  (((nElem/3) + block.x - 1) / block.x);
```
Change the sumArraysOnGPU function as shown below
```c
__global__ void sumArraysOnGPU(float *A, float *B, float *C, const int N)
{
 int nthreads = gridDim.x * blockDim.x;
 int i = blockIdx.x * blockDim.x + threadIdx.x;
 int j = i + nthreads;
 int k = j + nthreads;
 if (i < N) C[i] = A[i] + B[i];
 if (j < N) C[j] = A[j] + B[j];
 if (k < N) C[k] = A[k] + B[k];
}
```


|  Thread Block Size 	|  Kernel Time 	|  
|---	                |---	        |
|   256	                |   0.000355s   |  
|   512	                |   0.000353s   |  
|   768	                |   0.000368s   |  
|   1024	            |   0.000362s   |  

With these modifications, executing sumArraysOnGPU with a variety of block configurations produces the performance results in the above table. This is a result of improved global memory bandwidth utilization. 

# Q5. 
In sumMatrixOnGPU.cu, consider 2D grid 1D block. Write a new kernel function that handle three elements. Find the best grid configurations.

Similar to the previous problem, the grid is changed to 

```c
grid.x  = ((nx/3)  + block.x - 1) / block.x;
```
and the previous kernel function is commented and the new kernel function is written in sumMatrixOnGPU.cu

The device kernel is modified to process three elements in each thread, and the execution configuration
is modified to launch one third as many threads.

|  Thread Block Size 	|  Kernel Time 	|  
|---	                |---	        |
|   32	                |   0.024902s   |  
|   64	                |   0.019472s   |  
|   128	                |   0.017993s   |
|   256	                |   0.018002s   |  
|   512	                |   0.018043s   |  

Based on the kernel times recorded above, we can see that thread block size of 128 is a best grid configuration. 