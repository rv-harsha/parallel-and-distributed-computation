## Q2 ##
The delta value in host code is changed to -2 and executed (line 385--> test_shfl_up<<<1, block>>>(d_outData, d_inData, -2)).

The output from test_shfl_up with a negative delta (-2) is shown below:
shfl up                 :  0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15

Passing a negative value to __shfl_up leads to that negative value being cast to a very large unsigned integer, as delta is defined in the function declaration as an unsigned integer:

int __shfl_up(int var, unsigned int delta, int width=warpSize);

As a result, passing a negative value means that none of the deltas correspond to existing threads. The calling thread’s value is then returned from __shfl_up. Hence, the output for test_shfl_up with a negative delta is identical to the initial data.

## Q3 ##

test_shfl_wrap_plus is the name of the new kernel in simpleShfl.cu. Both the host and device function have been provided.
The output/result is printed as "shfl wrap custom" in "Q3 Custom Shfl Wrap Execution.png" file. 

## Q4 ##

test_shfl_xor_custom is the name of the new kernel in simpleShfl.cu. Both the host and device function have been provided.
The output/result is printed as "shfl xor custom" in "Q4 Shfl XOR Custom Execution.png" file. 

## Q5 ##
test_shfl_xor_array_custom is the name of the new kernel in simpleShfl.cu. Both the host and device function have been provided.
The output/result is printed as "shfl array custom" in "Q5 Shfl XOR Array Custom Execution.png" file. 

The output from the specified execution is:

shfl array custom       :  0  1  2  4  4  5  6  0  8  9 10 12 12 13 14  8

Essentially, each thread is responsible for a four-element chunk. Each thread tid performs its shuffle operation with either tid+1 if tid is even, or tid-1 if tid is odd. This shuffle operation replaces the fourth element of the other thread’s chunk with the first element of the current thread’s chunk. Therefore, the chunk that thread 1 is responsible for (indices 4-7 inclusive) has the last element (index 7) replaced with the first element in thread 0’s chunk (index 0). This pattern is then repeated for all other even-odd pairs of threads (2 and 3, 4 and 5, etc).

## Q6 ##

test_shfl_double_p_wrap is the name of the new kernel in simpleShfl.cu. Both the host and device function have been provided.
The output/result is printed as "shfl wrap double" in "Q6 Shfl Double Precision Wrap Mesh Execution.png" file.   

## Q7 ##

warpReduceCustom is the name of the new kernel in reduceIntegerShfl.cu. It is the equivalent function (of WarpReduce) that uses the __shfl_down instruction instead. The output/result is printed in "Q7 Shfl Down Kernel Execution.png" file.   