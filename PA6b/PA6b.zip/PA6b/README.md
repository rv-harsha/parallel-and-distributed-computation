## Q5 ##

We might state that it might not be used as each warp has only one instruction decode unit you might indeed not need syncthreads(). We might likely to end up with performance that is lower than if you were to run your algorithm on the CPU. Any divergences like that the compiler/hardware will automagically sync them for you. Including for loops and any kind of branch. Presumably we want all threads to be at the same point since they are reading data written by other threads into shared memory, if we are launching a single warp (in each block) then we know that all threads are executing together. On the face of it this means you can omit the __syncthreads(), a practice known as "warp-synchronous programming". However, there are a few things to consider as descibed below as technically, we should always use __syncthreads() to conform with the CUDA Programming Model.

Currently, NVIDIA makes no guarantee that the warp size of future GPU architectures will always remain 32 threads. While it’s probable that it will remain 32 for quite a while, there is no guarantee.

Therefore, code should really use cudaGetDeviceProperties() to query the warp size of the present GPU. Then make sure you always use __syncthreads() in code that has shared-memory dependencies between threads not in the same warp (in other words write your code so it sets the granularity of its SIMD computations to equal the warp size from cudaGetDeviceProperties()).

If we don’t do this, code may break on future architectures.

There is one situation where you can’t rely on correct behavior without __syncthreads(). That is when shared variables are cached in registers until a __syncthreads() is hit. Syncthreads has a second meaning: flush all cached shared variables.

That is, if there is a shared variable called “x”, and there is a spin wait on x, then there must be a __syncthreads, or each thread will see its own copy of x and the loop will never exit. Another way around this is to declare x as volatile, forcing the shared variable to be coherent in shared memory.