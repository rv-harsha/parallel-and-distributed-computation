#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <pthread.h>

#define NUM_THREADS 3

pthread_mutex_t mutex;

struct  thread_data{
        int     thread_id;
        int     cookies;
        int     *shelf;
};

struct  thread_data  thread_data_array[NUM_THREADS];

void *consumer(void *threadarg){
        
        struct  thread_data * my_data;
        my_data = (struct thread_data *) threadarg;
        int my_id = my_data->thread_id;
        int cookies = my_data->cookies;

        printf("Created Consumer with %d id.\n",my_id);

        while(cookies < 15){

                pthread_mutex_lock(&mutex);

                int *shelf = my_data->shelf;
                int shelf_initial = *shelf;

                if(*shelf>0){
                    cookies++;
                    (*shelf)--;   
                }
        	printf("Consumer %d has taken %d cookies. # of cookies" 
                " on the shelf changes from %d to %d cookies\n", my_id, 
                cookies, shelf_initial, *shelf);

        	pthread_mutex_unlock(&mutex);
        }
        printf("Terminating Consumer with %d id.\n",my_id);
}

void *producer(void *threadarg){

        struct  thread_data * my_data;
        my_data = (struct thread_data *) threadarg;
        int my_id = my_data->thread_id;
        int cookies = my_data->cookies;
        

        printf("Created Producer with %d id.\n",my_id);

        while(cookies<30){

                pthread_mutex_lock(&mutex);

                int *shelf = my_data->shelf;
                int shelf_initial = *shelf;

                if(*shelf<9){
                    cookies=cookies+2;
                    (*shelf)=(*shelf)+2;   
                }
                else if(*shelf == 9){
                    cookies++;
                    (*shelf)++;          
                }
        
                printf("Producer %d has put %d cookies. # of cookies" 
                " on the shelf changes from %d to %d cookies\n", my_id, 
                cookies, shelf_initial, *shelf);

        	pthread_mutex_unlock(&mutex);
        }
        printf("Terminating Producer with %d id.\n",my_id);
}


int main(void){

	int i, rc;
	pthread_t  threads[NUM_THREADS];
	int shelf = 0;

	pthread_mutex_init(&mutex, NULL);
	
	for(i=0; i<NUM_THREADS; i++) 
        {
                thread_data_array[i].thread_id = i;
                thread_data_array[i].cookies = 0;
                thread_data_array[i].shelf = &shelf;
        
                if(i==0){
                        rc = pthread_create(&threads[i], NULL, producer , 
                        (void *) &thread_data_array[i] );
                }
                else{
                        rc = pthread_create(&threads[i], NULL, consumer , 
                        (void *) &thread_data_array[i] );
                }
                if (rc) { printf("ERROR; return code from pthread_create()"
                " is %d\n", rc); exit(-1);}
        }

        for(i=0; i<NUM_THREADS; i++) 
        {
                rc = pthread_join(threads[i], NULL);
                if (rc) { printf("ERROR; return code from pthread_join()"
                " is %d\n", rc); exit(-1);}
        }
        
        printf("Producer-Consumer problem simulation with mutex only is completed.\n");

        pthread_mutex_destroy(&mutex);
		
	return 0;
}