Organization of files for this submission
-----------------------------------------

1. Respective files pertaining to C code, outputs and screenshots of execution have been provided under the named directories. 
2. (.out files) under outputs directory are simple text files. Please open them using a simple text editor. 

Problem 2a Observation
----------------------

From the plot we can notice that execution time decreases as number of threads increases, but however increasing the number of threads above 8 seem to affect the performance due to increasing overhead for thread management. So some number between 8-16 can be an optimal thread value for this 4K x 4K matrix multiplication using parallel thread execution.
