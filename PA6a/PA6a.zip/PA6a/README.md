## Q2 ## 

Solution is available in globalVariable.cu. It declares the global array as follows:

__device__ float devData[5];

and initializes it using cudaMemcpyToSymbol. The kernel is launched with five threads and the results of its modifications copied back using cudaMemcpyFromSymbol

## Q3 ## 

Implementation is provided in sumArrayZerocpy.cu. Measuring execution time on a GPU with offset 11 and L1 cache enabled shows better performance than with L1 cache disabled. These results demonstrate that the L1 cache is not only used for caching global loads, but also for loads from system memory. By enabling L1 cache, partial re-use of earlier reads leads to improved bus utilization. From the results, you can see that if you share a small amount of data between the host and device,zero-copy memory may be a good choice because it simplifies programming and offers reasonable performance. For larger datasets with discrete GPUs connected via the PCIe bus, zero-copy memory is a poor choice and causes significant performance degradation.

## Q4 ## 

It demonstrates a significant loss in both load and store throughput. This may indicate that not all loads and stores are being concurrently scheduled. ipc_instance indicates the number of instructions being executed per cycle on the GPU. If each load instruction were being issued concurrently, followed by all store instructions, then you would expect these to be approximately equal to without unrolling. However, you can see another significant loss in performance in this metric. This would indicate that warps are stalling on memory operations, leading to fewer instructions per cycle. There could be a variety of factors causing this. For instance, the compiler might reduce the number of concurrent memory operations to reduce the number of registers required by each thread. It might also might be unable to determine that the reads and writes are independent and can be scheduled concurrently.

## Q5 ## 

|   S.NO	|   Kernel	|  Execution Time 	|
|---	    |---	    |---	            |
|   1	    | CopyRow  |  0.000056 sec     |
|   2	    | CopyCol   |  0.000125 sec     |
|   3	    | NaiveRow  |  0.000116 sec     |
|   4	    | NaiveCol  |  0.000067 sec     |
|   5	    | Unroll4Row|  0.000115 sec     |
|   6	    | Unroll8Row|  0.000114 sec     |
|   7	    | Unroll4Col|  0.000062 sec     |
|   8	    | DiagonalRow| 0.000110 sec     |
|   9	    | DiagonalCol| 0.000060 sec     |

The performance comparison to some of the other transpose kernels is provided in Table above. Row kernels (except CopyRow) demonstrates a significant loss in performance due to poor strided memory access patterns. Here the main problem is load performance.
To support this explanation of performance loss, global memory throughput and efficiency can be measured.  Load efficiency is extremely low, due to strided reads. Load throughput is mediocre. Because reads are strided, many unnecessary bytes are being requested and keeping the bus busy. As a result, load throughput is artificially inflated. However, stores are still coalesced across a warp, so store efficiency is good. Store throughput is still low because so much kernel time is spent blocked waiting on loads, that stores never have a chance to consume bus capacity.

A performance comparison with the most similar transpose kernel, transposeUnroll4Row. The only change from transposeUnroll4Row to transposeUnroll8Row is more running threads and a smaller unrolling factor. transposeUnroll8Row demonstrates a performance improvement relative to transposeUnroll4Row. Note that while efficiencies remain approximately the same, both load and store throughput increase for transposeUnroll8Row as a result of more concurrently scheduled I/O operations within each thread.

## Q6 ##

The execution time is similar on lines for other kernels as executed for the previous question. However, the device allocated to run this case is a P100. 
We can see that unrolling and avoiding partition camping results in significant performance improvement. Unrolling leads to better coalescing of memory coalesces in transposeDiagonalColUnroll4, causing fewer memory transactions while still avoiding partition camping.